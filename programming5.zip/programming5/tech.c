#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

int main() {
    int i, j;
    int progress = 0;

    char *messages[] = {
        "Initializing system...",
        "Connecting to server...",
        "Scanning network...",
        "Decrypting data...",
        "Checking security...",
        "Access verification..."
    };

    srand(time(NULL));

    system("color 0A");

    for (i = 0; i < 6; i++) {

        system("cls");

        printf("\n========================================\n");
        printf("        SYSTEM SECURITY SCANNER\n");
        printf("========================================\n\n");

        printf("[+] %s\n\n", messages[i]);

        for (j = 0; j < 30; j++) {
            printf("%c", 33 + rand() % 94);
        }

        printf("\n\n");

        progress = (i + 1) * 16;

        printf("Progress: [");

        for (j = 0; j < 30; j++) {
            if (j < progress / 4)
                printf("#");
            else
                printf("-");
        }

        printf("] %d%%\n", progress);

        Sleep(800);
    }

    system("cls");

    printf("\n========================================\n");
    printf("          ACCESS GRANTED\n");
    printf("========================================\n\n");

    printf("      >>> SYSTEM UNLOCKED <<<\n\n");

    printf("User      : Pratiraj\n");
    printf("Status    : VERIFIED\n");
    printf("Security  : PASSED\n");

    printf("\n========================================\n");

    return 0;
}
