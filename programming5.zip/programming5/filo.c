#include <stdio.h>

int main() {
    FILE *tech;

    tech = fopen("data.txt", "a");

    fputc('l', tech);
    fputc('i', tech);
    fputc('k', tech);
    fputc('e', tech);
    fputc('s', tech);
    fputc('u', tech);
    fputc('b', tech);
    fputc('s', tech);
    fputc('c', tech);
    fputc('r', tech);
    fputc('i', tech);
    fputc('b', tech);
    fputc('e', tech);
   

    fclose(tech);

    return 0;
}
